# zippers > 2024-03-11 11:32pm
https://universe.roboflow.com/teste1-s5b34/zippers

Provided by a Roboflow user
License: CC BY 4.0

